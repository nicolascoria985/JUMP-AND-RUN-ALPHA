import java.util.ArrayList;

ArrayList<Plataforma> listaPlataformas = new ArrayList<Plataforma>(); 
ArrayList<Enemigo> listaEnemigos = new ArrayList<Enemigo>();       

float proximaPlataformaX = 400; 

Jugador heroe;
PImage imgMario;
float gravedad = 0.4;


float camaraX = 0; 
float anchoSuelo = 400;
float anchoNubeBucle = 300;


boolean izquierda = false;
boolean derecha = false;

void setup() {
  size(800, 600);
  
 
  imgMario = loadImage("mario sprite.png");

 
  reiniciarJuego();
}

void draw() {
  background(135, 206, 235); // Cielo
  

  heroe.teclaIzquierda = izquierda;
  heroe.teclaDerecha = derecha;
  heroe.actualizar(gravedad);
 

  if (heroe.x > width / 2) {
    camaraX = heroe.x - width / 2;
  }
  

  float camaraNubes = camaraX * 0.3;
  int nubeInicio = floor(camaraNubes / anchoNubeBucle);
  int nubesVisibles = ceil(width / anchoNubeBucle) + 1;
  
  pushMatrix();
  translate(-camaraNubes, 0);
  fill(255, 255, 255, 200);
  noStroke();
  for (int i = nubeInicio; i <= nubeInicio + nubesVisibles; i++) {
    float nubeX = i * anchoNubeBucle;
    ellipse(nubeX + 50,  100, 60, 50);
    ellipse(nubeX + 80,  90,  80, 60);
    ellipse(nubeX + 110, 100, 60, 50);
    ellipse(nubeX + 200, 150, 70, 45);
    ellipse(nubeX + 230, 145, 90, 55);
  }
  popMatrix();
  stroke(0);
  

  heroe.enElSuelo = false; 
  int bloqueInicio = floor(camaraX / anchoSuelo);
  int bloquesVisibles = ceil(width / anchoSuelo) + 1;
  
  pushMatrix();
  translate(-camaraX, 0);
  

  fill(34, 139, 34); 
  for (int i = bloqueInicio; i <= bloqueInicio + bloquesVisibles; i++) {
    float sueloX = i * anchoSuelo;
    float sueloY = 500;
    float sueloAlto = 100;
    
    rect(sueloX, sueloY, anchoSuelo, sueloAlto);
    heroe.verificarColisionSuelo(sueloX, sueloY, anchoSuelo);
  }
  
 
  for (int i = listaPlataformas.size() - 1; i >= 0; i--) {
    Plataforma plat = listaPlataformas.get(i);
    plat.mostrar(); // Dibuja la plataforma actual
    

    heroe.verificarColisionSuelo(plat.pos.x, plat.pos.y, plat.ancho);
    

    if (plat.pos.x < camaraX - 200) {
      listaPlataformas.remove(i);
    }
  }
  

  for (int i = listaEnemigos.size() - 1; i >= 0; i--) {
    Enemigo ene = listaEnemigos.get(i);
    ene.actualizar();
    ene.dibujar();
    

    float marioCentroX = heroe.x + (heroe.ancho / 2);
    float marioCentroY = heroe.y + (heroe.alto / 2);
    
    float distancia = dist(marioCentroX, marioCentroY, ene.x, ene.y);
    float radioMario = heroe.ancho / 2; 
    
    if (distancia < (radioMario + ene.radio)) {
      if (heroe.velY > 0 && (heroe.y + heroe.alto) < ene.y + 10) {
        listaEnemigos.remove(i); 
        heroe.velY = -9;     
        heroe.enElSuelo = false;
      } 
      else {
        heroe.recibirDano(); 
      }
    }
    else if (ene.x < camaraX - 200) {
      listaEnemigos.remove(i);
    }
  }
  
  if (proximaPlataformaX < camaraX + width + 400) {
    crearNuevaPlataforma();
  }
  
  if (heroe.y > height + 100) {
    heroe.vidas = 0; 
  }
  

  heroe.dibujar(imgMario);
  
  popMatrix();
  
  textSize(24);
  fill(255);
  stroke(0);
  strokeWeight(4);
  text("VIDAS: " + heroe.vidas, 20, 40);
  

  if (heroe.vidas <= 0) {
    fill(0, 0, 0, 180); 
    rect(0, 0, width, height);
    
    fill(255, 50, 50);
    textSize(50);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 20);
    
    fill(255);
    textSize(20);
    text("Presiona 'R' para volver a jugar", width / 2, height / 2 + 40);
    textAlign(LEFT, BASELINE); 
    noLoop(); 
  }
}

void crearNuevaPlataforma() {
  float aleatorioY = random(300, 450); 
  Plataforma nuevaPlat = new Plataforma(proximaPlataformaX, aleatorioY);
  listaPlataformas.add(nuevaPlat);
  

  if (random(100) < 60) {
    float puntoMedioX = nuevaPlat.pos.x + (nuevaPlat.ancho / 2);
    float radioEnemigo = 15;
    Enemigo nuevoEne = new Enemigo(puntoMedioX, nuevaPlat.pos.y, radioEnemigo, nuevaPlat.pos.x, nuevaPlat.ancho);
    listaEnemigos.add(nuevoEne);
  }
  
  proximaPlataformaX += random(250, 350); 
}


void reiniciarJuego() {
  listaPlataformas.clear();
  listaEnemigos.clear();
  proximaPlataformaX = 400;
  camaraX = 0;
  izquierda = false;
  derecha = false;
  
  heroe = new Jugador(100, 300); 
  
  for(int i = 0; i < 5; i++) {
    crearNuevaPlataforma();
  }
  loop();
}
