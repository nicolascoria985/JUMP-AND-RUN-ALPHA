class Enemigo {
  float x, y;
  float radio;
  float velocidadX;
  PImage sprite;
  
 
  float limiteIzquierdo;
  float limiteDerecho;
  

  Enemigo(float xInicial, float yInicial, float radioInicial, float inicioPlat, float anchoPlat) {
    x = xInicial;
    y = yInicial;
    radio = radioInicial;
    velocidadX = 1.5; 
    
    limiteIzquierdo = inicioPlat + radio;
    limiteDerecho = inicioPlat + anchoPlat - radio;
    
    sprite = loadImage("enemigo(2).png");
  }
  
  void actualizar() {
    x += velocidadX;
    
    if (x <= limiteIzquierdo) {
      x = limiteIzquierdo;
      velocidadX *= -1;
    }
    if (x >= limiteDerecho) {
      x = limiteDerecho;
      velocidadX *= -1;
    }
  }
  
 void dibujar() {
  if (sprite != null) {
    pushStyle();
    imageMode(CORNER); 
    image(sprite, x - radio, y - radio * 2, radio * 2, radio * 2);
    popStyle();
  } else {
    fill(150, 0, 255);
    ellipse(x, y - radio, radio * 2, radio * 2);
  }
}

}
